import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, index, jsonb, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Songs table - stores worship songs with chords and lyrics
export const songs = pgTable("songs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  artist: text("artist"),
  originalKey: text("original_key").notNull(), // e.g., "C", "G", "Am", "D#"
  lyrics: text("lyrics").notNull(), // Multi-line format: chord line followed by lyric line
  tags: text("tags").array(), // e.g., ["worship", "praise", "fast"]
  arrangement: text("arrangement"), // e.g., "Intro, Verse 1, Chorus, Verse 2, Chorus, Bridge, Chorus x2, Outro"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Musicians table - band members and worship team
export const musicians = pgTable("musicians", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  instrument: text("instrument"), // e.g., "Guitar", "Piano", "Vocals"
  teamCategory: text("team_category").notNull().default("Band Musicians"), // "Band Musicians", "Song Leaders", "Media", "Backup Singers", "Dancers"
  contact: text("contact"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Song leaders table
export const songLeaders = pgTable("song_leaders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  contact: text("contact"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Positions table - predefined roles for setlists
export const positions = pgTable("positions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(), // "Keys", "2nd Keys", "Electric Guitar", etc.
  order: integer("order").notNull(), // Display order
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Setlists table - collections of songs for services
export const setlists = pgTable("setlists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  date: timestamp("date").notNull(),
  songLeaderId: varchar("song_leader_id").references(() => songLeaders.id),
  notes: text("notes"),
  isTemplate: integer("is_template").default(0).notNull(), // 0 = false, 1 = true
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Setlist songs junction table - songs in a setlist with ordering
export const setlistSongs = pgTable("setlist_songs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  setlistId: varchar("setlist_id").notNull().references(() => setlists.id, { onDelete: "cascade" }),
  songId: varchar("song_id").notNull().references(() => songs.id, { onDelete: "cascade" }),
  order: integer("order").notNull(), // Position in setlist
  transposedKey: text("transposed_key"), // If different from original
}, (table) => ({
  uniqueSetlistOrder: unique().on(table.setlistId, table.order),
}));

// Setlist musicians junction table - musicians assigned to a setlist
export const setlistMusicians = pgTable("setlist_musicians", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  setlistId: varchar("setlist_id").notNull().references(() => setlists.id, { onDelete: "cascade" }),
  musicianId: varchar("musician_id").notNull().references(() => musicians.id, { onDelete: "cascade" }),
  positionId: varchar("position_id").references(() => positions.id), // Optional: for fixed position assignments
});

// Song usage tracking - when and how often songs are used
export const songUsage = pgTable("song_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  songId: varchar("song_id").notNull().references(() => songs.id, { onDelete: "cascade" }),
  setlistId: varchar("setlist_id").notNull().references(() => setlists.id, { onDelete: "cascade" }),
  usedAt: timestamp("used_at").notNull(),
});

// Insert schemas
export const insertSongSchema = createInsertSchema(songs).omit({
  id: true,
  createdAt: true,
});

export const insertMusicianSchema = createInsertSchema(musicians).omit({
  id: true,
  createdAt: true,
});

export const insertSongLeaderSchema = createInsertSchema(songLeaders).omit({
  id: true,
  createdAt: true,
});

export const insertSetlistSchema = createInsertSchema(setlists).omit({
  id: true,
  createdAt: true,
});

export const insertSetlistSongSchema = createInsertSchema(setlistSongs).omit({
  id: true,
});

export const insertSetlistMusicianSchema = createInsertSchema(setlistMusicians).omit({
  id: true,
});

export const insertPositionSchema = createInsertSchema(positions).omit({
  id: true,
  createdAt: true,
});

export const insertSongUsageSchema = createInsertSchema(songUsage).omit({
  id: true,
});

// Types
export type Song = typeof songs.$inferSelect;
export type InsertSong = z.infer<typeof insertSongSchema>;

export type Musician = typeof musicians.$inferSelect;
export type InsertMusician = z.infer<typeof insertMusicianSchema>;

export type SongLeader = typeof songLeaders.$inferSelect;
export type InsertSongLeader = z.infer<typeof insertSongLeaderSchema>;

export type Setlist = typeof setlists.$inferSelect;
export type InsertSetlist = z.infer<typeof insertSetlistSchema>;

export type SetlistSong = typeof setlistSongs.$inferSelect;
export type InsertSetlistSong = z.infer<typeof insertSetlistSongSchema>;

export type SetlistMusician = typeof setlistMusicians.$inferSelect;
export type InsertSetlistMusician = z.infer<typeof insertSetlistMusicianSchema>;

export type Position = typeof positions.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;

export type SongUsage = typeof songUsage.$inferSelect;
export type InsertSongUsage = z.infer<typeof insertSongUsageSchema>;

// Extended types for API responses
export type SetlistWithDetails = Setlist & {
  songLeader?: SongLeader;
  songs: Array<SetlistSong & { song: Song }>;
  musicians: Array<SetlistMusician & { musician: Musician; position?: Position }>;
};

export type SongWithUsage = Song & {
  usageCount: number;
  lastUsed?: Date;
};

// User types for Replit Auth
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
